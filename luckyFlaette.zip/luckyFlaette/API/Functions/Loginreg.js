const Logindata = {
  Flaette: "123456",
};
const startbalance = {
  data: {
    money: "10000$",
  }
};
const aktiveuser = [];
  
const Bankbalance = {
  Flaette: {
    money: "10000$",
  },
};

module.exports = {
  async checklogin(req, res){
    try{
    if(aktiveuser.length = 0){
      res.json({
       loggedin: false,
      });
    }
    else if(aktiveuser.length > 0){
      res.json({
        loggedin: true,
        user: aktiveuser[0],
       });
    }
  }catch(error){
    console.error(error);
    res.json({
      err: true,
      text: "Something isn't working",
    });
  }
  
  },

  async logindata(req, res){
    try{
       res.json({
       err: false,
       user: aktiveuser[0],
       money: Bankbalance[aktiveuser[0]].money,
      });
   
  }catch(error){
    console.error(error);
    res.json({
      err: true,
      text: "Something isn't working",
    });
  }
  },

  async login(req, res) {
    try {
      if (Logindata[req.body.username] == req.body.password) {
        aktiveuser.length = 0;
        aktiveuser.push(req.body.username);
        res.json({
          err: false,
          login: true,
          loggedinas: aktiveuser,
          bankaccount: Bankbalance[req.body.username].money,
        });
        
      } else {
        res.json({
          err: true,
          login: false,
        });
      }
    } catch (error) {
      console.error(error);
      res.json({
        err: true,
        text: "Something isn't working",
      });
    }
  },
  async changepassword(req, res) {
    try {
      if (Logindata[req.body.username] == req.body.oldpassword) {
        Logindata[req.body.username] = req.body.newpassword;
        res.json({
          err: false,
          changed: true,
          newPassword: Logindata[req.body.username],
        });
      } else {
        res.json({
          err: true,
          changed: false,
          text: "wrong user credentials",
        });
      }
    } catch (error) {
      console.error(error);
      res.json({
        err: true,
        text: "Something isn't working",
      });
    }
  },

  async register(req, res) {
    try {
      if (!Logindata[req.body.username]) {
        Logindata[req.body.username] = req.body.password;
        Bankbalance[req.body.username] = startbalance.data;
        res.json({
          err: false,
          registered: true,
          [req.body.username]: Logindata[req.body.username],
        });
      } else {
        res.json({
          err: true,
          registered: false,
          text: "username already exists",
        });
      }
    } catch (error) {
      console.error(error);
      res.json({
        err: true,
        text: "Something isn't working",
      });
    }
  },
};
