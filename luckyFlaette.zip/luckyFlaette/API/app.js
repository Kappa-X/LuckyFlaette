const express = require("express");
const app = express();
const port = 6900;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
const cors = require("cors");
const { login, register, changepassword, checklogin, logindata } = require("./Functions/Loginreg");
app.use(cors());

app.listen(port, () => console.log(`API ist live on http://localhost:${port}`));

{
  app.post("/login", login);
  app.post("/register", register);
  app.post("/changepassword", changepassword);
  app.get("/checklogin", checklogin);
  app.get("/logindata", logindata);
}
