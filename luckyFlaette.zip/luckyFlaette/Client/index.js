const Register = document.getElementById("Register");
const Login = document.getElementById("Login");
var UsernameL = document.getElementById("UsernameL");
var PasswordL = document.getElementById("PasswordL");
var UsernameR = document.getElementById("UsernameR");
var PasswordR = document.getElementById("PasswordR");
var UsernameC = document.getElementById("UsernameC");
var PasswordC = document.getElementById("PasswordC");
var Newpassword = document.getElementById("NewPassword");
const Passwordbtn = document.getElementById("SubmitPassword");
var ConfirmedPass = document.getElementById("PasswordConfirm");
const Loginbtn = document.getElementById("SubmitLogin");
const Loginnav1 = document.getElementById("Loginnav1");
const Loginnav2 = document.getElementById("Loginnav2");
const Registerbtn = document.getElementById("SubmitRegister");
const Registernav = document.getElementById("Registernav");
const Changepassword = document.getElementById("ChangePassword");
const Changepasswordnav = document.getElementById("ChangePasswordnav");
var UserData;

if(sessionStorage.getItem("loggedin") == "true"){
  document.getElementById("hh").style.display = "block";
  document.getElementById("Mainbtn").style.display = "block";
  document.getElementById("Logoutbtn").style.display = "block";
  Login.style.display = "none";
  Register.style.display = "none";
  Changepassword.style.display = "none";
  document.getElementById("header").style.display = "none";
}
else{
  document.getElementById("hh").style.display = "none";
  document.getElementById("Mainbtn").style.display = "none";
  document.getElementById("Logoutbtn").style.display = "none";
  Register.style.display = "none";
  Changepassword.style.display = "none"; 
}



Loginbtn.addEventListener("click", Loginfunc);
Registerbtn.addEventListener("click", Registerfunc);
Registernav.addEventListener("click", Showregister);
Loginnav1.addEventListener("click", ShowLogin);
Loginnav2.addEventListener("click", ShowLogin);
Changepasswordnav.addEventListener("click", ShowPasschange);
Passwordbtn.addEventListener("click", ChangePassword);
document.getElementById("Logoutbtn").addEventListener("click", logout);

function Loginfunc(event) {
  event.preventDefault();
  const Username2 = UsernameL.value;
  const Password2 = PasswordL.value;

  if (Username2 == "") {
    alert("Username must be filled out");
  } else if (Password2.length < 6) {
    alert("The password must have 6 characters or more");
  } else {
    const Logindata = {
      username: Username2,
      password: Password2,
    };

    const options = {
      method: "post",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(Logindata),
    };

    fetch("http://localhost:6900/login", options)
      .then((response) => {
        return response.json();
      })
      .then((jsondata) => {
        console.log(jsondata);
        if (jsondata.login == true) {
          alert("You Successfully Logged in!");
          Userlogged();
          UserData = jsondata;
          UsernameL.value = "";
          PasswordL.value = "";
          Login.style.display = "none";
          Register.style.display = "none";
          Changepassword.style.display = "none";
          document.getElementById("header").style.display = "none";
          document.getElementById("hh").style.display = "block";
          document.getElementById("Mainbtn").style.display = "block";
          document.getElementById("Logoutbtn").style.display = "block";
          sessionStorage.setItem("loggedin", "true");
        } else if (jsondata.login == false) {
          alert("Wrong User Credentials!");
        }
      });
  }
}
function Registerfunc(event) {
  event.preventDefault();
  const Username2 = UsernameR.value;
  const Password2 = PasswordR.value;
  const ConfirmedPass2 = ConfirmedPass.value;

  if (Username2 == "") {
    alert("Username must be filled out");
  } else if (Password2.length < 6) {
    alert("The password must have 6 characters or more");
  } else if (ConfirmedPass2 != Password2) {
    alert("Your Password and Your Confirmed Password need to be the same!");
  } else {
    const RegisterData = {
      username: Username2,
      password: Password2,
    };

    const options = {
      method: "post",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(RegisterData),
    };

    fetch("http://localhost:6900/register", options)
      .then((response) => {
        return response.json();
      })
      .then((jsondata) => {
        console.log(jsondata);
        if (jsondata.registered == true) {
          alert("You successfully Registered your new account!");
          alert("You can now Login with your new account.");
          UsernameR.value = "";
          PasswordR.value = "";
          ConfirmedPass.value = "";
          Login.style.display = "block";
          Register.style.display = "none";
        } else if (jsondata.registered == false) {
          alert("A user with this name already exists!");
        }
      });
  }
}
function ChangePassword(event) {
  event.preventDefault();
  const Username = UsernameC.value;
  const oldPassword = PasswordC.value;
  const newPassword = Newpassword.value;

  if (Username == "") {
    alert("Username must be filled out!");
  } else if (oldPassword == "") {
    alert("Your old Password must be filled out!");
  } else if (newPassword.length < 6) {
    alert("Your new Password must have al leat 6 characters! 🛸");
  } else {
    const data = {
      username: Username,
      oldpassword: oldPassword,
      newpassword: newPassword,
    };

    const options = {
      method: "post",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    };

    fetch("http://localhost:6900/changepassword", options)
      .then((response) => {
        return response.json();
      })
      .then((jsondata) => {
        console.log(jsondata);
        if (jsondata.changed == true) {
          alert("You successfully changed your password!");
          alert("You can now Login with your new password.");
          UsernameC.value = "";
          PasswordC.value = "";
          Newpassword.value = "";
          Login.style.display = "block";
          Changepassword.style.display = "none";
        } else if (jsondata.changed == false) {
          alert("Wrong User credentials!");
        } else {
          alert("Server Error Something went wrong 😶‍🌫️");
        }
      });
  }
}

function Showregister(event) {
  event.preventDefault();
  Login.style.display = "none";
  Register.style.display = "block";
}

function ShowLogin(event) {
  event.preventDefault();
  Login.style.display = "block";
  Register.style.display = "none";
  Changepassword.style.display = "none";
}

function ShowPasschange(event) {
  event.preventDefault();
  Login.style.display = "none";
  Changepassword.style.display = "block";
}


function Userlogged() {
  const options = {
    method: "GET",
  };
  fetch("http://localhost:6900/logindata", options)
    .then((response) => {
      return response.json();
    })
    .then((jsonData) => {
      console.log(jsonData);
      const A = jsonData.user;
      const B = jsonData.money;

      sessionStorage.setItem("username", A);
      sessionStorage.setItem("money", B);
    });
}

function logout(){
  sessionStorage.setItem("loggedin", "false");
  document.getElementById("hh").style.display = "none";
  document.getElementById("Mainbtn").style.display = "none";
  document.getElementById("Logoutbtn").style.display = "none";
  document.getElementById("header").style.display = "block";
  Login.style.display = "block";
  sessionStorage.clear("username");
  sessionStorage.clear("money");
}





